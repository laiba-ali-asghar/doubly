#ifndef laiba_double_linked_list
#define laiba_double_linked_list

#include <iostream>
#include <cmath>
#include <string>

using namespace std;
template <typename t>
class DNode
{
    t data;
    DNode<t> *next;
    DNode<t> *prev;

public:
    DNode()
    {
        next = prev = NULL;
    }
    DNode(t val)
    {
        data = val;
        next = prev = NULL;
    }
};
template <typename t>
class CDLinkedList
{
private:
    DNode<t> *head;

public:
    CDLinkedList();
    ~CDLinkedList();

    void insertAtHead(t val);
    void insertAtTail(t val);

    void removeAtHead();
    void removeAtTail();
    void remove(t val);

    bool search(t key);
    void update(t key, t val);
    int countNodes();
};
template <typename t>
 CDLinkedList<t>:: CDLinkedList()
 {
    head=NULL;
 }
 template <typename t>
 CDLinkedList<t>:: ~CDLinkedList()
{
    DNode<t>* temp=head;
    while()
}
template <typename t>
void CDLinkedList<t>::insertAtHead(t val)
{
    DNode<t> *newnode=new DNode<t> (val);
    if (head == nullptr)
    {
        head = newnode;
        newnode->next = newnode;
        newnode->prev = newnode;
        return;
    }
    else
    {
        DNode<t> *temp = head;
        while (temp->next != head)
        {
            temp = temp->next;
        }
        head->prev = newnode;

        newnode->next = head;
        head = newnode;
        temp->next = head;
    }
}
template <typename t>
void CDLinkedList<t>::insertAtTail(t val)
{
    DNode<t> *newnode=new DNode<t> (val);
    if (head == nullptr)
    {
        
        insertAtHead(val);
    }
    else
    {
        DNode<t> *temp = head;
        while (temp->next != head)
        {
            temp = temp->next;
        }
        temp->next = newnode;
        newnode->prev = temp;
        newnode->next = head;
    }
}

template <typename t>
void CDLinkedList<t>::removeAtHead()
{
    if (head == nullptr)
    {
        return;
    }
    if (head->next == head)
    {
        delete head;
        head = NULL;
    }
    else
    {

        DNode<t> *temp = head;
        DNode<t> *node_to_del = head;
        while (temp->next != head)
        {
            temp = temp->next;
        }
        head = head->next;
        head->prev = NULL;
        temp->next = head;
        node_to_del->next = NULL;
        delete node_to_del;
        return;
    }
}

template <typename t>
void CDLinkedList<t>::removeAtTail()
{
    if (head == nullptr)
    {
        return;
    }
    if
        else(head->next == head)
        {
            delete head;
            head = NULL;
            return;
        }
    else
    {
        DNode<t> *tail = head;
        DNode<t> *temp;
        while (tail->next != head)
        {
            tail = tail->next;
        }
        temp = tail;
        tail = tail->prev;
        tail->next = head;
        temp->prev = NULL;
        temp->next = NULL;
        delete temp;
        return;
    }
}
template <typename t>
void CDLinkedList<t>::remove(t val)
{
    if (head == nullptr)
    {
        return;
    }
    if ((head->data == val) && (head->next == head))
    {
        delete[] head;
        head = NULL;
        return;
    }
    if ((head->data == val) && (head->next->next == head))//messy
    {
        head = head->next;
        head->prev = NULL;
        head->next = head;
        delete[] head;
        return;
    }
    else
    {
        DNode<t> *temp = head;
        while (temp->next != head)
        {
            if (temp->data == val)
            {
                temp->next->prev = temp->prev;
                temp->prev->next = temp->next;
                temp->next = NULL;
                temp->prev = NULL;
                delete temp;
                return;
            }
            temp=temp->next;
        }
    }
}
template <typename t>
bool CDLinkedList<t>::search(t key)
{
    if (head == nullptr)
    {
        return false;
    }
    DNode<t> *temp = head;
    while (temp->next != head)
    {
        if (temp->data == val)
        {
            return true;
        }
        temp = temp->next;
    }
    return false;
}
template <typename t>
void CDLinkedList<t>::update(t key, t val)
{
    if (head == nullptr)
    {
        return;
    }
    DNode<t> *temp = head;
    while (temp->next != head)
    {
        if (temp->data == key)
        {
            temp->data = val;
            return;
        }
        temp = temp->next;
    }
    cout << "value not matched so nothing is updated\n";
    return;
}
template <typename t>
int CDLinkedList<t>::countNodes()
{
    int count = 1;
    if (head == nullptr)
    {
        return 0;
    }
    else
    {
        DNode<t> *temp = head->next;
        while (temp != head)
        {
            count++;
            temp = temp->next;
        }
    }
    return count;
}

#endif