#include <iostream>
#include "DLLSS.H"
#include <string>

using namespace std;

int main() {
    CDLinkedList<int> list;

    cout << "\n--- Inserting at Head ---\n";
    list.insertAtHead(10);
    list.insertAtHead(20);
    list.insertAtHead(30);
    list.display();

    cout << "\nNumber of nodes after insertAtHead: " << list.countNodes() << endl;

    cout << "\n--- Inserting at Tail ---\n";
    list.insertAtTail(40);
    list.insertAtTail(50);
    list.display();
    cout << "Number of nodes after insertAtTail: " << list.countNodes() << endl;

    cout << "\n--- Searching ---\n";
    cout << "Search 20: " << (list.search(20) ? "Found" : "Not Found" ) << endl;
    cout << "Search 100: " << (list.search(100) ? "Found" : "Not Found") << endl;

    cout << "\n--- Updating ---\n";
    list.update(20, 200);
    cout << "Updated 20 → 200.\n";
    list.display();

    cout << "\n--- Removing nodes ---\n";
    list.removeAtHead();
    cout << "Removed at head.\n";
    list.display();
    list.removeAtTail();
    cout << "Removed at tail.\n";
    list.display();
    list.remove(200);
    cout << "Removed node with data 200.\n";
    list.display();
    cout << "\nRemaining nodes count: " << list.countNodes() << endl;

    cout << "\n--- Destructor will run automatically when program ends ---\n";
    // return 0;
    return 0;
}